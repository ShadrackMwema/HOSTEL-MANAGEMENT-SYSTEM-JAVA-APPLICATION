import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import java.awt.event.ActionListener;

public class attendance {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hostel_management_system?zeroDateTimeBehavior=convertToNull";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = null;


    public attendance() {
        // Create a new JFrame to display the student table
        JFrame studentFrame = new JFrame("attendance  Details");
        studentFrame.setSize(800, 400);

        // Create a JTable with the student data
        JTable studentTable = new JTable(new DefaultTableModel(getInitialData(), getColumnNames()));

        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(studentTable);

        // Create a panel for the buttons at the bottom
        JPanel buttonPanel = createButtonPanel(studentTable);

        // Add the button panel and the JScrollPane to the JFrame
        studentFrame.add(scrollPane, BorderLayout.CENTER);
        studentFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Make the JFrame visible
        studentFrame.setLocationRelativeTo(null);
        studentFrame.setVisible(true);



    }
    private static String[][] getInitialData() {
        List<String[]> data = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "SELECT Name, RegNo, PhoneNumber, ParentPhoneNumber, Room, Block FROM attendance";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String[] rowData = new String[]{
                        resultSet.getString("Name"),
                        resultSet.getString("RegNo"),
                        resultSet.getString("PhoneNumber"),
                        resultSet.getString("ParentPhoneNumber"),
                        resultSet.getString("Room"),
                        resultSet.getString("Block")
                };
                data.add(rowData);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return data.toArray(new String[0][0]);
    }

    private static String[] getColumnNames() {
        return new String[]{"Names", "Reg No", "Phone Number", "Parent Phone Number", "Room", "Block"};
    }


    private static JPanel createButtonPanel(JTable studentTable) {
        JPanel buttonPanel = new JPanel();
        addButton(buttonPanel, "Add Student", e -> displayAddStudentForm(studentTable));
        addButton(buttonPanel, "Edit Student", e -> editSelectedStudent(studentTable));
        addButton(buttonPanel, "Delete Student", e -> deleteSelectedStudent(studentTable));
        addButton(buttonPanel, "Save Details", e -> saveDetailsToDatabase(studentTable));
        return buttonPanel;
    }

    private static void editSelectedStudent(JTable studentTable) {
        int selectedRow = studentTable.getSelectedRow();

        if (selectedRow != -1) {
            String[] rowData = getSelectedRowData(studentTable, selectedRow);
            displayEditStudentForm(studentTable, selectedRow, rowData);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a student to edit.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static String[] getSelectedRowData(JTable studentTable, int selectedRow) {
        String[] rowData = new String[getColumnNames().length];
        for (int i = 0; i < getColumnNames().length; i++) {
            rowData[i] = studentTable.getValueAt(selectedRow, i).toString();
        }
        return rowData;
    }

    private static void deleteSelectedStudent(JTable studentTable) {
        int selectedRow = studentTable.getSelectedRow();

        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
            model.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a student to delete.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private static void addButton(JPanel panel, String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        panel.add(button);
    }

    private static void displayEditStudentForm(JTable studentTable, int selectedRow, String[] rowData) {
        JFrame editStudentFrame = new JFrame("Edit Student");
        editStudentFrame.setSize(400, 300);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(6, 2));

        JTextField nameField = new JTextField(rowData[0]);
        JTextField regNoField = new JTextField(rowData[1]);
        JTextField phoneNumberField = new JTextField(rowData[2]);
        JTextField parentPhoneNumberField = new JTextField(rowData[3]);
        JTextField roomField = new JTextField(rowData[4]);
        JTextField blockField = new JTextField(rowData[5]);

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Reg No:"));
        formPanel.add(regNoField);
        formPanel.add(new JLabel("Phone Number:"));
        formPanel.add(phoneNumberField);
        formPanel.add(new JLabel("Parent/Guardian Phone.No:"));
        formPanel.add(parentPhoneNumberField);
        formPanel.add(new JLabel("Room:"));
        formPanel.add(roomField);
        formPanel.add(new JLabel("Block:"));
        formPanel.add(blockField);

        JPanel buttonPanel = new JPanel();
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(e -> {
            String[] updatedData = {
                    nameField.getText(),
                    regNoField.getText(),
                    phoneNumberField.getText(),
                    parentPhoneNumberField.getText(),
                    roomField.getText(),
                    blockField.getText()
            };

            DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
            model.removeRow(selectedRow);
            model.insertRow(selectedRow, updatedData);

            editStudentFrame.dispose();
        });

        cancelButton.addActionListener(e -> editStudentFrame.dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        editStudentFrame.add(formPanel, BorderLayout.CENTER);
        editStudentFrame.add(buttonPanel, BorderLayout.SOUTH);

        editStudentFrame.setLocationRelativeTo(null);
        editStudentFrame.setVisible(true);
    }

    private static void displayAddStudentForm(JTable studentTable) {
        JFrame addStudentFrame = new JFrame("Add Student");
        addStudentFrame.setSize(400, 300);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(6, 2));

        JTextField nameField = new JTextField();
        JTextField regNoField = new JTextField();
        JTextField phoneNumberField = new JTextField();
        JTextField parentPhoneNumberField = new JTextField();
        JTextField roomField = new JTextField();
        JTextField blockField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Reg No:"));
        formPanel.add(regNoField);
        formPanel.add(new JLabel("Phone Number:"));
        formPanel.add(phoneNumberField);
        formPanel.add(new JLabel("Parent/Guardian Phone.No:"));
        formPanel.add(parentPhoneNumberField);
        formPanel.add(new JLabel("Room:"));
        formPanel.add(roomField);
        formPanel.add(new JLabel("Block:"));
        formPanel.add(blockField);

        JPanel buttonPanel = new JPanel();
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(e -> {
            String[] rowData = {
                    nameField.getText(),
                    regNoField.getText(),
                    phoneNumberField.getText(),
                    parentPhoneNumberField.getText(),
                    roomField.getText(),
                    blockField.getText()
            };

            DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
            model.addRow(rowData);

            addStudentFrame.dispose();
        });

        cancelButton.addActionListener(e -> addStudentFrame.dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        addStudentFrame.add(formPanel, BorderLayout.CENTER);
        addStudentFrame.add(buttonPanel, BorderLayout.SOUTH);

        addStudentFrame.setLocationRelativeTo(null);
        addStudentFrame.setVisible(true);
    }
    private static void saveDetailsToDatabase(JTable studentTable) {
        try {
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Delete all existing records
            String deleteQuery = "DELETE FROM attendance";
            PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
            deleteStatement.executeUpdate();

            // Insert new records
            String insertQuery = "INSERT INTO attendance (Name, PhoneNumber, ParentPhoneNumber, Room, Block, RegNo) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);

            DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
            int rowCount = model.getRowCount();

            try {
                for (int i = 0; i < rowCount; i++) {
                    insertStatement.setString(1, model.getValueAt(i, 0).toString());
                    insertStatement.setString(2, model.getValueAt(i, 2).toString());
                    insertStatement.setString(3, model.getValueAt(i, 3).toString());
                    insertStatement.setString(4, model.getValueAt(i, 4).toString());
                    insertStatement.setString(5, model.getValueAt(i, 5).toString());
                    insertStatement.setString(6, model.getValueAt(i, 1).toString());

                    insertStatement.executeUpdate();
                }

                JOptionPane.showMessageDialog(null, "Details saved to database.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } finally {
                if (deleteStatement != null) {
                    deleteStatement.close();
                }
                if (insertStatement != null) {
                    insertStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error saving details to database: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }




}
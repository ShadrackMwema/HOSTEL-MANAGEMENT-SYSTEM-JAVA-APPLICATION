import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.awt.event.ActionListener;


class RoomManager {

    private JFrame roomFrame;
    private JTable roomTable;
    private JTextField[] textFields; // Added class-level JTextField array
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hostel_management_system?zeroDateTimeBehavior=convertToNull";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = null;
    public RoomManager() {
        // Initialize the frame and table
        roomFrame = new JFrame("Room Details");
        roomFrame.setSize(800, 400);

        // Define column names for room details
        String[] roomColumnNames = {"Block No", "Room No", "No of Students", "Beds", "Chairs", "Curtains", "Accommodation Fee"};

        // Define initial room data (replace this with your actual data)
        Object[][] roomData = {
                {"A", "101", 2, 2, 2, "Yes", 500.0},
                {"B", "201", 3, 3, 3, "No", 700.0},
                // Add more rows as needed
        };

        // Create a JTable with room data
        roomTable = new JTable(new DefaultTableModel(roomData, roomColumnNames));

        // Add the table to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(roomTable);

        // Create a panel for the buttons at the bottom
        JPanel buttonPanel = new JPanel();
        addButton(buttonPanel, "Add Room", e -> displayAddRoomForm());
        addButton(buttonPanel, "Edit Room", e -> editSelectedRoom());
        addButton(buttonPanel, "Delete Room", e -> deleteSelectedRoom());
        addButton(buttonPanel, "Save Details", e ->  saveDetailsToMySQL());

        // Add the button panel and the JScrollPane to the JFrame
        roomFrame.add(scrollPane, BorderLayout.CENTER);
        roomFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Make the JFrame visible
        roomFrame.setLocationRelativeTo(null);
        roomFrame.setVisible(true);
    }

    private void editSelectedRoom() {
        int selectedRow = roomTable.getSelectedRow();

        if (selectedRow != -1) {
            Object[] rowData = getSelectedRowData(roomTable, selectedRow);
            displayEditRoomForm(selectedRow, rowData);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a room to edit.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private Object[] getSelectedRowData(JTable table, int selectedRow) {
        Object[] rowData = new Object[table.getColumnCount()];
        for (int i = 0; i < table.getColumnCount(); i++) {
            rowData[i] = table.getValueAt(selectedRow, i);
        }
        return rowData;
    }

    private void deleteSelectedRoom() {
        int selectedRow = roomTable.getSelectedRow();

        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) roomTable.getModel();
            model.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(null, "Please select a room to delete.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void displayEditRoomForm(int selectedRow, Object[] rowData) {
        JFrame editRoomFrame = new JFrame("Edit Room");
        editRoomFrame.setSize(400, 300);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(7, 2));

        textFields = new JTextField[7]; // Initialize the JTextField array

        for (int i = 0; i < 7; i++) {
            textFields[i] = new JTextField(rowData[i].toString());
            formPanel.add(new JLabel(roomTable.getColumnName(i) + ":"));
            formPanel.add(textFields[i]);
        }

        createAndShowEditRoomForm(selectedRow, editRoomFrame, formPanel);
    }

    private void createAndShowEditRoomForm(int selectedRow, JFrame editRoomFrame, JPanel formPanel) {
        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        // Add action listener to save button
        saveButton.addActionListener(e -> {
            // Get the updated data
            Object[] updatedData = new Object[7];
            for (int i = 0; i < 7; i++) {
                updatedData[i] = textFields[i].getText();
            }

            // Update the data in the table
            DefaultTableModel model = (DefaultTableModel) roomTable.getModel();
            model.removeRow(selectedRow);
            model.insertRow(selectedRow, updatedData);

            // Close the edit room form
            editRoomFrame.dispose();
        });

        // Add action listener to cancel button
        cancelButton.addActionListener(e -> editRoomFrame.dispose());

        // Add buttons to the buttonPanel
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        // Add panels to the editRoomFrame
        editRoomFrame.add(formPanel, BorderLayout.CENTER);
        editRoomFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Make the editRoomFrame visible
        editRoomFrame.setLocationRelativeTo(null);
        editRoomFrame.setVisible(true);
    }

    private void displayAddRoomForm() {
        JFrame addRoomFrame = new JFrame("Add Room");
        addRoomFrame.setSize(400, 300);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(7, 2));

        textFields = new JTextField[7]; // Initialize the JTextField array

        for (int i = 0; i < 7; i++) {
            textFields[i] = new JTextField();
            formPanel.add(new JLabel(roomTable.getColumnName(i) + ":"));
            formPanel.add(textFields[i]);
        }

        createAndShowAddRoomForm(addRoomFrame, formPanel);
    }

    private void createAndShowAddRoomForm(JFrame addRoomFrame, JPanel formPanel) {
        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        // Add action listener to save button
        saveButton.addActionListener(e -> {
            Object[] rowData = new Object[7];
            for (int i = 0; i < 7; i++) {
                rowData[i] = textFields[i].getText();
            }

            DefaultTableModel model = (DefaultTableModel) roomTable.getModel();
            model.addRow(rowData);

            addRoomFrame.dispose();
        });

        // Add action listener to cancel button
        cancelButton.addActionListener(e -> addRoomFrame.dispose());

        // Add buttons to the buttonPanel
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        // Add panels to the addRoomFrame
        addRoomFrame.add(formPanel, BorderLayout.CENTER);
        addRoomFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Make the addRoomFrame visible
        addRoomFrame.setLocationRelativeTo(null);
        addRoomFrame.setVisible(true);
    }

    private void addButton(Container container, String text, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Set a maximum size to ensure all buttons have the same width
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));

        // Add ActionListener to the button if provided
        if (actionListener != null) {
            button.addActionListener(actionListener);
        }

        container.add(button);
    }

    private void saveDetailsToMySQL() {
        try {
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Delete existing records from the "Rooms" table
            String deleteQuery = "DELETE FROM Rooms";
            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                deleteStatement.executeUpdate();
            }

            // Insert data from the JTable into the "Rooms" table
            String insertQuery = "INSERT INTO Rooms (BlockNo, RoomNo, NoOfStudents, Beds, Chairs, Curtains, AccommodationFee) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                DefaultTableModel model = (DefaultTableModel) roomTable.getModel();
                for (int i = 0; i < model.getRowCount(); i++) {
                    insertStatement.setString(1, model.getValueAt(i, 0).toString()); // Block No
                    insertStatement.setString(2, model.getValueAt(i, 1).toString()); // Room No
                    insertStatement.setInt(3, (int) model.getValueAt(i, 2)); // No of Students
                    insertStatement.setInt(4, (int) model.getValueAt(i, 3)); // Beds
                    insertStatement.setInt(5, (int) model.getValueAt(i, 4)); // Chairs
                    insertStatement.setString(6, model.getValueAt(i, 5).toString()); // Curtains
                    insertStatement.setDouble(7, (double) model.getValueAt(i, 6)); // Accommodation Fee

                    insertStatement.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(null, "Details saved to MySQL successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error saving details to MySQL.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }






}